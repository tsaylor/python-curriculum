# -*- coding: utf-8 -*-
name = raw_input('What is your name?\n')
print("Nice to meet you " + name)

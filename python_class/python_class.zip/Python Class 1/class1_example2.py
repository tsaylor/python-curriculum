# -*- coding: utf-8 -*-
print('Old McDonald had a farm')

print('Ee i ee i oh')

print('And on his farm he had some chickens')

print('Ee i ee i oh')

print('With a cluck cluck here')

print('And a cluck cluck there')

print('Old McDonald had a farm')

print('Ee i ee i oh')

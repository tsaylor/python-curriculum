# -*- coding: utf-8 -*-
# Sing Old McDonald

animals = "cows"

noise = "moo moo"

print("Old McDonald had a farm")

print("Ee i ee i oh")

print("And on his farm he had some " + animals)

print("Ee i ee i oh")

print("With a " + noise + " here")

print("And a ” + noise + “ there")

print("Old McDonald had a farm")

print("And on his farm he had some " + animals)

print("Ee i ee i oh")

print("With a " + noise + " here")

print("And a " + noise + " there")

print("Old McDonald had a farm")
print("Ee i ee i oh")
